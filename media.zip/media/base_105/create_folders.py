import os

i=0
j=1
current_directory = os.getcwd()
#dst = os.mkdir('base_'+ str(j)) 
dst = os.path.join(current_directory, 'base_'+ str(j))
os.mkdir(dst)
for file in os.listdir(current_directory):
    if (i >2):
        i=0
        j = j+1
        dst = os.path.join(current_directory, 'base_'+ str(j))
        os.mkdir(dst)
    print (os.path.join(current_directory, file))
    print (os.path.join(dst, file))
    os.rename(os.path.join(current_directory, file), os.path.join(dst, file))
    i = i + 1
    
    